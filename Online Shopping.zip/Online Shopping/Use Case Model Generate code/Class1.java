

/**
 * @author RAK
 * @version 1.0
 * @created 14-Jul-2023 8:02:19 PM
 */
public class Class1 {

	public Class1(){

	}

	public void finalize() throws Throwable {

	}

}