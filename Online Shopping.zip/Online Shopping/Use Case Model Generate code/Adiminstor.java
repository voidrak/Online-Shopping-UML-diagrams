

/**
 * @author RAK
 * @version 1.0
 * @created 14-Jul-2023 8:02:19 PM
 */
public class Adiminstor {

	public char name;
	private int password;
	public int worker_id;
	public customer m_customer;

	public Adiminstor(){

	}

	public void finalize() throws Throwable {

	}

	public int admin identification(){
		return 0;
	}

	public int manage catalogue(){
		return 0;
	}

}