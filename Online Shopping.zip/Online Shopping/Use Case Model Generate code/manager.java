

/**
 * @author RAK
 * @version 1.0
 * @created 14-Jul-2023 8:02:19 PM
 */
public class manager {

	public char manger_name;
	private char password;
	private int worker_id;
	public customer m_customer;

	public manager(){

	}

	public void finalize() throws Throwable {

	}

	public int manage orders(){
		return 0;
	}

	public int user identification(){
		return 0;
	}

}