

/**
 * @author RAK
 * @version 1.0
 * @created 14-Jul-2023 8:02:19 PM
 */
public class customer {

	private int password;
	private char username;

	public customer(){

	}

	public void finalize() throws Throwable {

	}

	public int purchase(){
		return 0;
	}

	protected char register(){
		return 0;
	}

}